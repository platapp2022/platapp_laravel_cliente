<?php 

return [
    'back' => 'atrás',
    'back_to_home' => 'Regresar al inicio',
    'page' => [
        'not_found' => 'Pagina no encontrada',
    ],
    'permission' => 'El usuario no tiene permiso',
    'store_disabled' => 'store_disabled',
]; 

