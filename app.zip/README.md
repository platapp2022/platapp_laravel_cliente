## Markets

Laravel web application

```
npm install -D tailwindcss@latest postcss@latest autoprefixer@latest
```

```
npx tailwindcss init
```

```
npm run dev
```
