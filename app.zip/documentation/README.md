## Upload on Server
Upload this zip folder to your server then
copy the .env file from you admin panel folder to this folder.


