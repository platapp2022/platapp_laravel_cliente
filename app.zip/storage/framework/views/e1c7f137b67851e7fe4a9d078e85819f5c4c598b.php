

<?php $__env->startSection('content'); ?>
    <!-- side bar -->
    <?php echo $__env->make('balde_components.navs.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
    <!-- top nav bar -->
    <?php echo $__env->make('balde_components.navs.nav-bar-v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <banner></banner>
    <?php echo $__env->make('balde_components.popular-categories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <main-index :app_name="`<?php echo e(setting('app_name')); ?>`" :countMarket=<?php echo e($countMarket); ?> ></main-index>

    <footer class="h-96 relative" >
        <img src="/images/bg3.jpg" alt="delivery" class="w-full h-full absolute top-0 left-0 object-cover">
        <div style="background: rgba(0, 0, 0, 0.281);" class="rounded w-full h-full absolute ">
        <div class="absolute p-4 top-1/4 right-12 h-2/4 w-2/3 md:w-1/3 bg-black rounded flex flex-col">
            <h2 class="text-white font-bold text-xl  md:text-3xl ">
                <?php echo e(__('Are you a Rider')); ?>?
            </h2>
            <p class="text-md text-gray-200 w-5/6">
                <?php echo e(__("indexPage_footer_banner_description")); ?>

            </p>
            <br>
            <a href="/contact-us" class="btn bg-green custom-btn-blue md:w-1/3 ">
                <?php echo e(__('Contact Us')); ?> 
            </a>
        </div>
        </div>
    </footer>
    <?php echo $__env->make('balde_components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Platapp_laravel_cliente\resources\views/welcome.blade.php ENDPATH**/ ?>