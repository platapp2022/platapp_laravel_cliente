<nav class="side-bar" id="side-bar" >
    <i id="cancel"> &times</i>
    <div class="top">
        <i class="fab fa-shopify text-2xl"></i>
        <span><?php echo e(setting('app_name')); ?></span>
    </div>
    <div class="links">
        <ul>
            <li><a href="/"> <i class="fas fa-home "></i> &nbsp; <?php echo e(__("Home")); ?></a></li>
            <li><a href="/markets"><i class="fas fa-store "></i> &nbsp; <?php echo e(__("Markets")); ?></a></li>
            <li><a href="/products"> <i class="fas fa-cubes "></i> &nbsp; <?php echo e(__("Products")); ?></a></li>
            
            <?php if(auth()->guard()->guest()): ?>
                <li><a href="/login"><i class="icon fas fa-sign-in-alt"></i> &nbsp; <?php echo e(__("Login")); ?> </a></li>
            <?php else: ?>
                <li><a href="/wishlist"><i class="icon far fa-heart"></i> &nbsp; <?php echo e(__("Favorites")); ?>  </a></li>
                <li><a href="/my-account"><i class="icon far fa-user"></i> &nbsp; <?php echo e(__("My account")); ?> </a></li>
                <li><a  href="<?php echo e(route('logout')); ?>" 
                    onclick="event.preventDefault();document.getElementById('logout-form').submit();"
                    ><i class="icon fas fa-door-open"></i> &nbsp;<?php echo e(__("Logout")); ?> </a>
                </li>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                </form>
           <?php endif; ?>

            

        </ul>
    </div>
</nav><?php /**PATH /home/platappm/public_html/resources/views/balde_components/navs/side-bar.blade.php ENDPATH**/ ?>