<section class="bg-gray-200  py-20 flex flex-col">
    <div class="container">
        <div class="w-full text-center">
            <div class="w-full  self-center content-center flex flex-row justify-center -mt-4 mb-6">
                <p class="border-1 border-green w-44"></p>
            </div>
            <h2 class="text-black text-4xl font-bold py-1">
                <?php echo e(__("popular_categories")); ?>

            </h2>
            <p class="text-gray-600 text-md font-normal  py-1">
                <?php echo e(__("popular_categories_description")); ?>

            </p>
        </div>
        <div class="h-full w-full  slider">
            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/fields/<?php echo e($field->id); ?>" class="p-4 nav-link hover:text-green-500 border-white">
                    <div class="relative w-full text-center">
                        
                        <div class="flex flex-col h-52 justify-center p-1">
                            <img class="text-green self-center" width="70%" src="<?php echo e($field->getFirstMediaUrl('image')); ?>" alt="">
                            <b class="mt-2 text-black"><?php echo e($field->name); ?></b> 
                            
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH /home/platappm/public_html/resources/views/balde_components/popular-categories.blade.php ENDPATH**/ ?>