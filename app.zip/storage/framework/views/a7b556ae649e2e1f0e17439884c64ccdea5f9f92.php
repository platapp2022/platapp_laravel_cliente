<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <script type="text/javascript" defer>
            const google_maps_key = "<?php echo setting('google_maps_key');?>"; 
            const LANG_I18N = "<?php echo setting('language');?>"; 
        </script>
        <style>
            :root {
                --main_color:<?php echo e(setting('main_color')); ?>;
            }
        </style>
        
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
        
        <title><?php echo e(setting('app_name')); ?> <?php echo $__env->yieldContent('title'); ?></title>
        
        <link rel="shortcut icon" href="<?php echo e($app_logo); ?>" type="image/x-icon"/>
        
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        
        <link href="<?php echo e(asset('css/tailwind.css')); ?>" rel="stylesheet">
        
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
        
        <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
        
        <?php echo $__env->yieldContent('extraStyle'); ?>
        
    </head>
    <body>
        <div id="app">
            <button type="button" id="top" class="z-50 hidden bg-green text-white text-2xl py-1 px-2 rounded-full outline-none border-none fixed bottom-2 right-5">
                <i class="fas fa-chevron-up"></i>
            </button>
            <?php echo $__env->yieldContent('content'); ?>
            <example-component></example-component>
        </div>
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        <script src="<?php echo e(asset('js/main.js')); ?>"></script>
        <script src="<?php echo e(asset('js/costum-slick.js')); ?>"></script>
        <?php echo $__env->yieldContent('extraJs'); ?>
        <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <script type="application/javascript">
                    Vue.notify({
                        group: 'bar',
                        type: 'error',
                        title: "<?php echo __('Important message') ?> ",
                        text: "<?php echo __('search Error') ?> "
                    })
                </script>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\Platapp_laravel_cliente\resources\views/layouts/master.blade.php ENDPATH**/ ?>