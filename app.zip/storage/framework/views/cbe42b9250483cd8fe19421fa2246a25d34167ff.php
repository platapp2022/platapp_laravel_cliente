<!-- navbar-brand -->
<div >
    <button id="show-side-bar" class="md:hidden nav-link absolute left-4 top-2 w-10 h-10 outline-none text-lg border-none"><i class="fas fa-align-left"></i></button>
    <a class="navbar-brand font-semibold hover:text-gray-900" href="/"><?php echo e(setting('app_name')); ?> </a>
    <?php if(auth()->guard()->guest()): ?>
        <a class="nav-link md:hidden absolute right-6 top-3 w-10 h-10 text-lg" href="/login">
            <i class="fas fa-sign-in-alt"></i>
        </a>
    <?php else: ?>
        <div class="btn-group absolute right-6 top-4  text-sm flex md:hidden">
            <button type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <img src="<?php echo e(auth()->user()->getFirstMediaUrl('avatar')); ?>" class="rounded-full object-cover w-8 h-8 shadow-xl" alt="user">   
            </button>
            <div class="dropdown-menu dropdown-menu-left -ml-28 mt-3" aria-labelledby="triggerId">
                <a class="dropdown-item text-black p-2"  href="/my-account" >
                    <i class="fas fa-user" ></i> <span><?php echo e(__("My account")); ?></span>
                </a>
                <a class="dropdown-item text-red-500 hover:text-red-400 hover:bg-gray-50 p-2" 
                    href="<?php echo e(route('logout')); ?>" 
                    onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                    <i class="fas fa-door-open" ></i> <span>Logout</span>
                </a>
            </div>
        </div> 
    <?php endif; ?>

</div>
<!-- links -->
<div class="hidden md:flex md:flex-row">
    <ul class="navbar-nav flex flex-row mr-auto ">
        <li class="nav-item ml-3">
            <a class="nav-link " aria-current="page" href="/"> 
                <i class="fas fa-home mr-1   "></i>           
                <?php echo e(__("Home")); ?>

            </a>
        </li>
        <li class="nav-item ml-3">
            <a class="nav-link " aria-current="page" href="/markets">
                <i class="fas fa-store mr-1   "></i>
                <?php echo e(__("Markets")); ?>

            </a>
        </li>
        <li class="nav-item ml-3">
            <a class="nav-link " aria-current="page" href="/products">
                <i class="fas fa-cubes mr-1   "></i>
                <?php echo e(__("Products")); ?>

            </a>
        </li>
        
        
        <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item ml-3">
                <a class="nav-link" href="/login"><i class=" icon fas fa-sign-in-alt"></i></a>
            </li>
        <?php else: ?>
        <li class="nav-item ml-3">
            <a class="nav-link" href="/wishlist"><i class="icon far fa-heart"></i></a>
        </li>
        <li class="nav-item ml-3  flex flex-row items-center">
            <div class="btn-group ml-3">
                <button class="dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo e(auth()->user()->name); ?>

                </button>
                <div class="dropdown-menu dropdown-menu-left -ml-20 mt-3" aria-labelledby="triggerId">
                    <a class="dropdown-item text-black p-2"  href="/my-account" >
                        <i class="fas fa-user" ></i> <span><?php echo e(__("My account")); ?></span>
                    </a>
                    <a class="dropdown-item text-red-500 hover:text-red-400 hover:bg-gray-50 p-2" 
                        href="<?php echo e(route('logout')); ?>" 
                        onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                        <i class="fas fa-door-open" ></i> <span>Logout</span>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </div>    
        </li>
        <?php endif; ?>
    </ul>
</div>
<?php /**PATH C:\Users\chimu\OneDrive\Escritorio\Trabajo\IQNETING\Nenis_laravel_cliente\resources\views/balde_components/navs/nav-content.blade.php ENDPATH**/ ?>